# ChineseHSK-v2 Görsel Süreklilik Kılavuzu

## Final görsel kuralı
- 9:16 dikey, tam ekran sahne sanatı.
- Uygulama butonları, altyazı, Pinyin/Türkçe, konuşma balonu görsele gömülmez.
- Doğal çevre tabelaları olabilir; ders/UI metni olamaz.
- Konuşan karakterin %8–10 büyümesi ve ağız animasyonu uygulama katmanında yapılır.

## Canonical ana aile (erken/orta dönem)
- **Zhang Wei:** kısa koyu saç, siyah dikdörtgen gözlük, mavi/lacivert dış katman.
- **Liu Mei:** uzun koyu kahverengi saç, krem/bej sıcak tonlar.
- **Yutong:** uzun koyu saç, pembe/mor palet; HSK ilerledikçe kontrollü yaşlandır.
- **Lele:** kısa koyu saç, mavi/yeşil palet; HSK ilerledikçe kontrollü yaşlandır.
- **Mimi:** turuncu-beyaz tekir.
- **Büyükanne/Büyükbaba:** HSK4+; gri saç, aynı yüz oranları ve sıcak stil.

## Dönem kilidi
- HSK1–2: çocuklar daha küçük; ev/okul/mahalle başlangıç dönemi.
- HSK3: kafe kuruluş dönemi; karakter yüzleri aynı, yaş ilerlemesi hafif.
- HSK4: büyükanne/büyükbaba ve ergenlik dönemi; yaş ilerlemesi görünür.
- HSK5–6: erken dönem çocuk görselleri **yeniden kullanılmaz**; yeni yaşlandırılmış canonical set üretilecek.

## Tutarlılık kararı
- `FINAL_SELECTED`: doğrudan sahneye bağlı ve canonical kimlikle uyumlu.
- `FAMILY_REFERENCE`: doğru stil/karakter ailesinde ancak final eşleme veya yaş kontrolü bekliyor.
- `HOLD_CAST_MISMATCH`: kaliteli fakat başka yüz/yaş seti; uygulamaya konmaz, yalnız referans.
- `UI_REFERENCE_ONLY`: tasarım referansı; sahne asset'i değildir.
- `REJECT_UNRELATED`: uygulama dışı/alakasız.
