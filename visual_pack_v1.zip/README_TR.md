# ChineseHSK Visual Pack v1

Bu paket 29 seçilmiş final sahne WebP dosyası, tam görsel envanteri ve süreklilik kılavuzunu içerir.
Repo köküne `visual_pack_v1.zip` adıyla yüklenirse güncellenmiş GitHub Actions akışı sahneleri otomatik olarak APK kaynaklarına kopyalar.
